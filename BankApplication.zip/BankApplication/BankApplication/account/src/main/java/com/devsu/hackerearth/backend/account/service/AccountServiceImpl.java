package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    private final ObjectMapper objectMapper;

    public AccountServiceImpl(AccountRepository accountRepository, ObjectMapper objectMapper) {
        this.accountRepository = accountRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<AccountDto> getAll() {
        List<Account> accountList = accountRepository.findAll();
        return accountList.stream()
                .map(account -> objectMapper.convertValue(account, AccountDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Account not found."));
        return objectMapper.convertValue(account, AccountDto.class);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        Account account = objectMapper.convertValue(accountDto, Account.class);
        Account savedAccount = accountRepository.save(account);
        return objectMapper.convertValue(savedAccount, AccountDto.class);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        accountRepository.findById(accountDto.getId())
                .orElseThrow(() -> new RuntimeException("account not found."));
        Account accountUpdated = accountRepository.save(objectMapper.convertValue(accountDto, Account.class));
        return objectMapper.convertValue(accountUpdated, AccountDto.class);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Account not found."));
        account.setActive(partialAccountDto.isActive());
        Account accountUpdated = accountRepository.save(account);
        return objectMapper.convertValue(accountUpdated, AccountDto.class);
    }

    @Override
    public void deleteById(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Account not found."));
        // Para efectos de la prueba cumplo con la funcionalidad de hacer el endpoint,
        // sin embargo siempre se recomienda un soft delete.
        accountRepository.delete(account);
    }

}
