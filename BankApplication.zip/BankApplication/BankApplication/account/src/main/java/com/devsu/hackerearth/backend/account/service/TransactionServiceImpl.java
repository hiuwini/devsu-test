package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    private final ObjectMapper objectMapper;

    public TransactionServiceImpl(TransactionRepository transactionRepository, ObjectMapper objectMapper,
            AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<TransactionDto> getAll() {
        List<Transaction> transactionList = transactionRepository.findAll();
        return transactionList.stream()
                .map(transaction -> objectMapper.convertValue(transaction, TransactionDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction not found."));
        return objectMapper.convertValue(transaction, TransactionDto.class);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) throws Exception {
        double balance = 0;

        Account accountTmp = accountRepository.findById(transactionDto.getAccountId())
                .orElseThrow(() -> new RuntimeException("The transaction contains account "
                        + transactionDto.getAccountId().toString() + " but not found this account in database."));

        Transaction transaction = objectMapper.convertValue(transactionDto, Transaction.class);

        List<Transaction> transactionListByAccountId = transactionRepository
                .findByAccountIdOrderByDateDesc(transactionDto.getAccountId());

        if (transactionListByAccountId.isEmpty()) {
            balance = accountTmp.getInitialAmount();
        } else {
            balance = transactionListByAccountId.get(0).getAmount();
        }

        transaction = makeTransaction(balance, transaction);

        Transaction savedtransaction = transactionRepository.save(transaction);
        return objectMapper.convertValue(savedtransaction, TransactionDto.class);
    }

    @Override
    public TransactionDto update(TransactionDto transactionDto) throws Exception {
        transactionRepository.findById(transactionDto.getId())
                .orElseThrow(() -> new Exception("Transaction not found."));
        Transaction transactionUpdated = transactionRepository
                .save(objectMapper.convertValue(transactionDto, Transaction.class));
        return objectMapper.convertValue(transactionUpdated, TransactionDto.class);
    }

    @Override
    public void deleteById(Long id) throws Exception {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new Exception("Transaction not found."));
        // Para efectos de la prueba cumplo con la funcionalidad de hacer el endpoint,
        // sin embargo siempre se recomienda un soft delete.
        transactionRepository.delete(transaction);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {

        List<BankStatementDto> report = transactionRepository.findTransactionsByAccountIdAndDateRange(clientId,
                dateTransactionStart, dateTransactionEnd);

        return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        return null;
    }

    private static Transaction makeTransaction(double balance, Transaction transaction)
            throws Exception {
        switch (transaction.getType()) {
            case "DEBIT":
                if (transaction.getAmount() > balance) {
                    throw new Exception("Saldo no disponible");
                }
                balance = balance - transaction.getAmount();
                transaction.setAmount(-(transaction.getAmount()));
                break;
            case "CREDIT":
                transaction.setBalance(balance + transaction.getAmount());
                break;
            default:
                throw new Exception("Invalid transaction type");
        }

        return transaction;
    }

}
