package com.devsu.hackerearth.backend.account.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findByAccountIdOrderByDateDesc(Long accountId);

    @Query("SELECT new com.devsu.hackerearth.backend.account.model.dto.BankStatementDto(t.date, c.name, a.number, a.type, a.initialAmount, a.isActive, t.type, t.amount, t.balance) "
            +
            "FROM Transaction t " +
            "INNER JOIN Account a ON t.accountId = a.id " +
            "INNER JOIN Client c ON a.clientId = c.id " +
            "WHERE t.accountId = :accountId AND t.date BETWEEN :startDate AND :endDate")
    List<BankStatementDto> findTransactionsByAccountIdAndDateRange(
            @Param("accountId") Long accountId,
            @Param("startDate") Date startDate,
            @Param("endDate") Date endDate);

}
