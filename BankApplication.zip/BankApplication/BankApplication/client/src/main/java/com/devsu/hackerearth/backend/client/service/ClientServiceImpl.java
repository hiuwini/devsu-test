package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	private final ClientMapper clientMapper;

	public ClientServiceImpl(ClientRepository clientRepository, ClientMapper clientMapper) {
		this.clientRepository = clientRepository;
		this.clientMapper = clientMapper;
	}

	@Override
	public List<ClientDto> getAll() {
		List<Client> clientList = clientRepository.findAll();
		return clientList.stream()
				.map(clientMapper::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Client not found."));
		return clientMapper.toDto(client);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		Client client = clientMapper.toEntity(clientDto);
		Client savedClient = clientRepository.save(client);
		return clientMapper.toDto(savedClient);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		clientRepository.findById(clientDto.getId())
				.orElseThrow(() -> new RuntimeException("Client not found."));
		Client clientUpdated = clientRepository.save(clientMapper.toEntity(clientDto));
		return clientMapper.toDto(clientUpdated);
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Client not found."));
		client.setActive(partialClientDto.isActive());
		Client clientUpdated = clientRepository.save(client);
		return clientMapper.toDto(clientUpdated);
	}

	@Override
	public void deleteById(Long id) {
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Client not found."));
		// Para efectos de la prueba cumplo con la funcionalidad de hacer el endpoint,
		// sin embargo siempre se recomienda un soft delete.
		clientRepository.delete(client);
	}
}
