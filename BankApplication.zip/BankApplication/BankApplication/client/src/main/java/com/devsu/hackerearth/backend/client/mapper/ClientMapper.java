package com.devsu.hackerearth.backend.client.mapper;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

@Component
public class ClientMapper {

    public ClientDto toDto(Client client) {
        ClientDto dto = new ClientDto();
        dto.setId(client.getId());
        dto.setName(client.getName());
        dto.setPhone(client.getPhone());
        dto.setAddress(client.getAddress());
        dto.setDni(client.getDni());
        dto.setGender(client.getGender());
        dto.setAge(client.getAge());
        dto.setActive(client.isActive());
        return dto;
    }

    public Client toEntity(ClientDto dto) {
        Client entity = new Client();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setPhone(dto.getPhone());
        entity.setAddress(dto.getAddress());
        entity.setDni(dto.getDni());
        entity.setGender(dto.getGender());
        entity.setAge(dto.getAge());
        entity.setActive(dto.isActive());
        return entity;
    }

}
